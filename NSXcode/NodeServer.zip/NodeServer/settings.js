(function(){
	var settings;

	settings = {

		db: {
			host: "localhost",
			port: "3306",
			user: "root",
			password: "root",
			database: "node"
		}
	};
	module.exports = settings;
}).call(this);
