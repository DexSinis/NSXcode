//
//  PeopleTableViewController.h
//  iosapp
//
//  Created by ChanAetern on 1/7/15.
//  Copyright (c) 2015 oschina. All rights reserved.
//

#import "OSCObjsViewController.h"

@interface PeopleTableViewController : OSCObjsViewController

@property (nonatomic, copy) NSString *queryString;

@end
